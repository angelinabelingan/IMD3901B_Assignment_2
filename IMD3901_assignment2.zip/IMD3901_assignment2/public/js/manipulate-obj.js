'use strict';

AFRAME.registerComponent('manipulate-obj', {
  init: function() {

    const Context_AF = this;
    let colorBox = document.querySelector('#color_box');
    
    
    //change box color on mouse hold 
    Context_AF.el.addEventListener('mouseup', function()  {
        colorBox.setAttribute('material', 'color', 'white');
    });

    Context_AF.el.addEventListener('mousedown', function() {
        colorBox.removeAttribute('material');
        colorBox.setAttribute('material', 'color', 'crimson');
    });
  }
});