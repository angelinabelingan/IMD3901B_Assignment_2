'use strict';


AFRAME.registerComponent('add-remove', { 
  init: function() {
    const Context_AF = this;

    let scene = document.querySelector('a-scene');

    //create entity 
    let entityBox  = document.createElement('a-entity')
    
    //listen on click
    Context_AF.el.addEventListener('mousedown', function() {

      if (document.getElementById("shape")) {
        //remove shape from scene 
        console.log('removed');
        scene.removeChild(entityBox);

        //remove shape attributes
        entityBox.removeAttribute('geometry');
        entityBox.removeAttribute('position');
        entityBox.removeAttribute('material');
      }
      else if (!document.getElementById("shape")){
        //add shape to scene 
        console.log('added');
        scene.appendChild(entityBox);

        //set shape attributes 
        entityBox.setAttribute('geometry', {
          primitive: 'box',
          height: 1,
          width: 1,
          depth: 1
        });
        entityBox.setAttribute('position', {x: 1, y: 2, z: -3});
        entityBox.setAttribute('material', 'color', 'white');
        entityBox.setAttribute('id', "shape");
      }
    });
  }

});